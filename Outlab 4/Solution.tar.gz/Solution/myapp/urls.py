from django.urls import path
from . import views
from django.contrib.auth.views import LoginView,LogoutView
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    path('',views.indexView,name="home"),
    path('login/',LoginView.as_view(),name="login_url"),
    path('register/',views.registerView,name="register_url"),
    path('logout/',LogoutView.as_view(next_page='login_url'),name="logout"),
    path('explore/',views.explore,name="explore"),
    path('profile/<int:pk>/',views.profileView,name="profile"),
    path('my/',views.myView,name="my"),
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
