from django.shortcuts import render, redirect, get_object_or_404
from .forms import SignUpForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from myapp.models import Profile, Repository
import requests
import datetime
# Create your views here.
def indexView(request):
    return render(request,'index.html')
@login_required()
def explore(request):
    displaynames=Profile.objects.all()
    return render(request, 'explore.html',{'User':displaynames})
def registerView(request):
    if request.method == "POST":
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login_url')
    else:
        form = SignUpForm()
    return render(request,'registration/register.html',{'form':form})

def profileView(request,pk):
    obj = Profile.objects.get(id=pk)
    get_repos = obj.repository_set.all().order_by('-stars')
    context2 = {'Repository':get_repos , 'obj':obj}
    return render(request, 'profile.html', context2)


def myView(request):
    user = request.user.username
    obj = request.user.profile
    response = requests.get('https://api.github.com/users/'+user)
    json_resp = response.json()
    response2 = requests.get('https://api.github.com/users/'+user+'/repos')
    json_response2 = response2.json()
    obj.full_name = json_resp['name']
    obj.followers = json_resp['followers']
    obj.last_update = datetime.datetime.now()
    obj.repos_count = json_resp['public_repos']
    obj.save()
    Repository.objects.filter(profile=obj).delete()
    if obj.repos_count > 30 :
        obj.repos_count = 30
    for i in range(obj.repos_count) :
        Repository.objects.create(rep_name = json_response2[i]['name'], stars = json_response2[i]['stargazers_count'], profile = obj)
    get_repos = obj.repository_set.all().order_by('-stars')
    context2 = {'Repository':get_repos , 'obj':obj}
    return render(request, 'profile.html', context2)
