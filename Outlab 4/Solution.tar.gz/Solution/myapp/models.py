from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    
    full_name = models.CharField(max_length=50, null=True)
    followers = models.IntegerField(null=True)
    repos_count = models.IntegerField(null=True)
    last_update = models.CharField(max_length=50, null=True)

    def __str__(self):
        return self.user.username

    def create_user_profile(sender, instance, created, **kwargs):
        if created:
            profile = Profile.objects.create(user=instance)

    post_save.connect(create_user_profile, sender=User)

class Repository(models.Model):
    profile = models.ForeignKey(Profile, on_delete=models.CASCADE)
    
    name = models.CharField(max_length=30)
    rep_name = models.CharField(max_length=50)
    stars = models.IntegerField()

    def __str__(self):
        return self.rep_name

