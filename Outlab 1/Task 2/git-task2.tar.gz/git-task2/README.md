# Simple Chat Server

This is a simple chat server that broadcasts messages to all users.

## Local Dev

To locally work and test, load creds.env into environment and compile using gcc.

To start server for prod, use make.sh.

### References

- [Beej's Socket Programming Guide](https://beej.us/guide/bgnet/pdf/bgnet_usl_c_1.pdf)

