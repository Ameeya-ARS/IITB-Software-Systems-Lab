gcc -o server server.c && ./server
